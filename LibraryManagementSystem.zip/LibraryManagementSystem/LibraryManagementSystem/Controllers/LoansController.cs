﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DBModels;

namespace LibraryManagementSystem.Controllers
{
    public class LoansController : Controller
    {
        private readonly DbRepo _context;

        public LoansController(DbRepo context)
        {
            _context = context;
        }

        // GET: Loans
        public async Task<IActionResult> Index()
        {
            var loans = await _context.Loans.ToListAsync();
            var book = await _context.Books.ToListAsync();
            var member = await _context.Members.ToListAsync();

            foreach (var item in loans)
            {
                if (book.Any(i => i.book_id == item.book_id))
                {
                    var bookname = book.Where(i => i.book_id == item.book_id).ToList();
                    item.bookName = bookname.FirstOrDefault().title;
                }

                if (member.Any(i => i.member_id == item.member_id))
                {
                    var membername = member.Where(i => i.member_id == item.member_id).ToList();
                    item.memberName = membername.FirstOrDefault().first_name + member.FirstOrDefault().last_name;
                }
            }
            return View(loans);
        }

        // GET: Loans/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loans = await _context.Loans
                .FirstOrDefaultAsync(m => m.loan_id == id);
            if (loans == null)
            {
                return NotFound();
            }

            return View(loans);
        }

        // GET: Loans/Create
        public async Task<IActionResult> Create()
        {
            var book=await _context.Books.ToListAsync();
            var members=await _context.Members.ToListAsync();
            //Dictionary<int, string> dictBooks = new Dictionary<int, string>();
            //Dictionary<int, string> dictMember = new Dictionary<int, string>();

            //if (book?.Count()>0)
            //{
            //    foreach (var item in book)    
            //    {
            //        dictBooks.Add(item.book_id,item.title);
            //    }
            //}
            //if (members?.Count() > 0)
            //{
            //    foreach (var item in members)
            //    {
            //        dictMember.Add(item.member_id, string.Concat(item.first_name,item.last_name));
            //    }
            //}
            Loans loans=new Loans()
            { ListBook=book,
            ListMember=members
            };
            return View(loans);
        }

        // POST: Loans/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("loan_id,book_id,member_id,loan_date,due_date,return_date")] Loans loans)
        {
            if (loans.book_id!=0&& loans.member_id!=0)
            {
                try
                {

                _context.Add(loans);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
					return RedirectToAction(nameof(Index));
				}
			}
            return View(loans);
        }

        // GET: Loans/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loans = await _context.Loans.FindAsync(id);
            if (loans == null)
            {
                return NotFound();
            }
            return View(loans);
        }

        // POST: Loans/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("loan_id,book_id,member_id,loan_date,due_date,return_date")] Loans loans)
        {
            if (id != loans.loan_id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(loans);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LoansExists(loans.loan_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(loans);
        }

        // GET: Loans/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loans = await _context.Loans
                .FirstOrDefaultAsync(m => m.loan_id == id);
            if (loans == null)
            {
                return NotFound();
            }

            return View(loans);
        }

        // POST: Loans/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var loans = await _context.Loans.FindAsync(id);
            if (loans != null)
            {
                _context.Loans.Remove(loans);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LoansExists(int id)
        {
            return _context.Loans.Any(e => e.loan_id == id);
        }
    }
}
