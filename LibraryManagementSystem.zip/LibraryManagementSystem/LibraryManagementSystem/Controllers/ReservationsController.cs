﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DBModels;

namespace LibraryManagementSystem.Controllers
{
    public class ReservationsController : Controller
    {
        private readonly DbRepo _context;

        public ReservationsController(DbRepo context)
        {
            _context = context;
        }

        // GET: Reservations
        public async Task<IActionResult> Index()
        {
            var reservaton = await _context.Reservations.ToListAsync();
            var book = await _context.Books.ToListAsync();
            var member = await _context.Members.ToListAsync();

            foreach (var item in reservaton)
            {
                if(book.Any(i => i.book_id== item.book_id))
                {
                    var bookname = book.Where(i => i.book_id == item.book_id).ToList();
                    item.bookName = bookname.FirstOrDefault().title;
                }

                if (member.Any(i => i.member_id == item.member_id))
                {
                    var membername = member.Where(i => i.member_id == item.member_id).ToList();
                    item.memberName = membername.FirstOrDefault().first_name+member.FirstOrDefault().last_name;
                }
            }
            return View(reservaton);
        }

        // GET: Reservations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservations = await _context.Reservations
                .FirstOrDefaultAsync(m => m.reservation_id == id);
            if (reservations == null)
            {
                return NotFound();
            }

            return View(reservations);
        }

        // GET: Reservations/Create
        public async Task<IActionResult> Create()
        {
			var book = await _context.Books.ToListAsync();
			var members = await _context.Members.ToListAsync();
			
			Reservations reservations = new Reservations()
			{
				ListBook = book,
				ListMember = members
			};


			return View(reservations);
        }

        // POST: Reservations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("reservation_id,book_id,member_id,reservation_date")] Reservations reservations)
        {
            if (reservations.book_id !=0 && reservations.member_id != 0)
            {
                try
                {
                    _context.Add(reservations);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(reservations);
        }

        // GET: Reservations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservations = await _context.Reservations.FindAsync(id);
            if (reservations == null)
            {
                return NotFound();
            }
            return View(reservations);
        }

        // POST: Reservations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("reservation_id,book_id,member_id,reservation_date")] Reservations reservations)
        {
            if (id != reservations.reservation_id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reservations);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReservationsExists(reservations.reservation_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(reservations);
        }

        // GET: Reservations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservations = await _context.Reservations
                .FirstOrDefaultAsync(m => m.reservation_id == id);
            if (reservations == null)
            {
                return NotFound();
            }

            return View(reservations);
        }

        // POST: Reservations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reservations = await _context.Reservations.FindAsync(id);
            if (reservations != null)
            {
                _context.Reservations.Remove(reservations);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReservationsExists(int id)
        {
            return _context.Reservations.Any(e => e.reservation_id == id);
        }
    }
}
