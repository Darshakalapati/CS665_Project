﻿namespace LibraryManagementSystem.Models.ViewModels
{
	public class DropViewModels
	{
        public int key { get; set; }
        public string Display { get; set; }
    }
}
